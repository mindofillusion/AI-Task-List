[CmdletBinding()]
param(
  [switch]$Uninstall,
  [switch]$NoCodex,
  [switch]$NoPause
)

$ErrorActionPreference = 'Stop'
$installDir = Join-Path $env:LOCALAPPDATA 'AI-Task-List'
$appDir = Join-Path $installDir 'app'
$browserSetupDir = Join-Path $installDir 'browser-setup'
$tray = Join-Path $appDir 'AI-Task-Collector.exe'
$runner = Join-Path $appDir 'node.exe'
$dataDir = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'AI-Task-List'
$snapshot = Join-Path $dataDir 'tasks.json'
$shortcutPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'AI Task List Collector.lnk'
$previousShortcutPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'AI Task Collector.lnk'
$payloadHashes = @{
  'AI-Task-Collector.exe' = '89305BC64F2374EC4E3AB25A2AC64D96BCBD6C1F2BC07C29493562AB801137D3'
  'node.exe' = '35D366F67382F0BA791DCABEDED8F6A6D5C77EFEE4D833F38C1DD3A1E6F160F8'
  'main.cjs' = 'BBFC41F6776F99C36F3A256FA59DFC7613FD22295911B7F2DDC7CA7DD5780763'
  'codex.cjs' = '5D874B6EEF9D71FF847778717F8EBA7204E282BB835AFD81949D523F838389E6'
  'clients.cjs' = '0B810D32803A25C58F0FC304989BF25F969B3B3DF06A37CDA8F82E8F90EE3957'
  'clients.json' = 'BDFC2E3F3E7ABD66181C41921752D0B9206EB080A12E774657B5811C5CAC2057'
  'usage.cjs' = '54A287A1FE170D047A2C788371A6E1A100E07843A5BE182A1B94D15D77DE5ED0'
}
$payloadDir = Join-Path $PSScriptRoot 'app'
$browserPayload = Join-Path $PSScriptRoot 'browser'
$browserHashes = @{
  'Install-ChatGPT-Web.ps1' = '54335FE7CDC34964831D78594355967A0F249083756593F9A195CD56228908CA'
  'AI-Task-List-Web.exe' = '960653A64EEC1DAB49F5C1996C268D1D54B1DD9F5FC7D3C07B893F8950C90AE2'
}
$browserFiles = @('Install-ChatGPT-Web.ps1', 'AI-Task-List-Web.exe', 'stores.json')

if (-not $Uninstall) {
  foreach ($file in $payloadHashes.Keys) {
    if ((Get-FileHash -LiteralPath (Join-Path $payloadDir $file) -Algorithm SHA256).Hash -ne $payloadHashes[$file]) {
      throw "Missing or modified collector file: $file"
    }
  }
  foreach ($file in $browserHashes.Keys) {
    if ((Get-FileHash -LiteralPath (Join-Path $browserPayload $file) -Algorithm SHA256).Hash -ne $browserHashes[$file]) {
      throw "Missing or modified browser installer file: $file"
    }
  }
  if (!(Test-Path -LiteralPath (Join-Path $browserPayload 'stores.json') -PathType Leaf)) {
    throw 'The browser store catalog is missing. Extract the complete Windows archive.'
  }
}

if (Test-Path -LiteralPath $tray -PathType Leaf) {
  $stop = Start-Process -FilePath $tray -ArgumentList '--stop' -WindowStyle Hidden -PassThru -Wait
  if ($stop.ExitCode -ne 0) { throw 'Unable to stop the running collector.' }
}

Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" |
  Where-Object { $_.ExecutablePath -eq $runner } |
  ForEach-Object {
    $runningCollector = Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue
    if ($runningCollector -and $runningCollector.Path -eq $runner) {
      Stop-Process -InputObject $runningCollector
      $runningCollector.WaitForExit()
    }
  }

if ($Uninstall) {
  $appFiles = $payloadHashes.Keys | ForEach-Object { Join-Path $appDir $_ }
  $browserInstallerFiles = $browserFiles | ForEach-Object { Join-Path $browserSetupDir $_ }
  foreach ($file in (@($shortcutPath, $previousShortcutPath, $snapshot) + $appFiles + $browserInstallerFiles)) {
    if (Test-Path -LiteralPath $file -PathType Leaf) { Remove-Item -LiteralPath $file }
  }
  Write-Host 'AI Task Collector removed. Provider files are preserved.'
  return
}

if (Test-Path -LiteralPath $previousShortcutPath -PathType Leaf) {
  Remove-Item -LiteralPath $previousShortcutPath -Force -ErrorAction SilentlyContinue
}

New-Item -ItemType Directory -Path $appDir,$browserSetupDir -Force | Out-Null
foreach ($file in $payloadHashes.Keys) {
  $destination = Join-Path $appDir $file
  if ($file -eq 'clients.json' -and (Test-Path -LiteralPath $destination -PathType Leaf)) { continue }
  Copy-Item -LiteralPath (Join-Path $payloadDir $file) -Destination $destination -Force
}
foreach ($file in $browserFiles) {
  Copy-Item -LiteralPath (Join-Path $browserPayload $file) -Destination $browserSetupDir -Force
}
$collectorArguments = if ($NoCodex) { '--no-codex' } else { '' }

# Verify that the installed executable can write its first snapshot before creating startup.
$collector = Start-Process -FilePath $tray -ArgumentList ("--once $collectorArguments") -WindowStyle Hidden -PassThru -Wait
if ($collector.ExitCode -ne 0) { throw "Collector startup failed ($($collector.ExitCode))." }

try {
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($shortcutPath)
  $shortcut.TargetPath = $tray
  $shortcut.Arguments = $collectorArguments
  $shortcut.WorkingDirectory = $installDir
  $shortcut.Description = 'Starts the local AI task collector for iCUE'
  $shortcut.WindowStyle = 1
  $shortcut.Save()
  if (-not (Test-Path -LiteralPath $shortcutPath -PathType Leaf)) {
    throw 'The shortcut did not appear in the startup folder.'
  }
} catch {
  Write-Warning "The collector will run for this session, but automatic startup could not be configured. $($_.Exception.Message)"
}
if ($NoCodex) {
  Start-Process -FilePath $tray -ArgumentList $collectorArguments -WindowStyle Hidden
} else {
  Start-Process -FilePath $tray -WindowStyle Hidden
}
Write-Host "AI Task Collector installed for the current user. Snapshot: $snapshot"
if (-not $NoPause -and [Environment]::UserInteractive) {
  [void](Read-Host 'Installation terminee. Appuyez sur Entree pour fermer / Installation complete. Press Enter to close')
}
